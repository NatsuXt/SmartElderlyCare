# 智慧养老系统 v2.0 部署指南

## 📦 部署包内容

```
SmartElderlyCare_Deploy_20250910_0059/
├── app/                    # 应用程序文件（从当前项目发布）
│   ├── RoomDeviceManagement.dll
│   ├── appsettings.json
│   └── ... (其他依赖文件)
├── scripts/                # 启动脚本
│   ├── start_server.bat    # Windows启动脚本
│   └── start_server.sh     # Linux/macOS启动脚本
├── config/                 # 配置文件模板
│   ├── appsettings.json
│   └── appsettings.Production.json
├── docs/                   # 项目文档
│   ├── README.md
│   ├── API端点测试指南.md
│   └── 房间入住管理API端点测试指南.md
└── DEPLOYMENT_GUIDE.md     # 本文件
```

## 🚀 快速部署

### Windows 服务器

1. **解压部署包**到目标目录
2. **修改数据库配置**：
   ```bash
   # 编辑 app/appsettings.json
   # 修改 ConnectionString 为你的Oracle数据库连接字符串
   ```
3. **运行启动脚本**：
   ```bash
   # 双击运行或命令行执行
   scripts\start_server.bat
   ```

### Linux/macOS 服务器

1. **解压部署包**到目标目录
2. **设置执行权限**：
   ```bash
   chmod +x scripts/start_server.sh
   ```
3. **修改数据库配置**：
   ```bash
   # 编辑 app/appsettings.json
   vim app/appsettings.json
   ```
4. **运行启动脚本**：
   ```bash
   ./scripts/start_server.sh
   ```

## ⚙️ 配置说明

### 数据库连接配置

编辑 `app/appsettings.json` 文件：

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=你的数据库地址:端口/服务名;User Id=用户名;Password=密码;Pooling=true;"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  }
}
```

### 端口配置

默认端口为 `3003`，如需修改：
- 编辑启动脚本中的 `--urls` 参数
- 或设置环境变量 `ASPNETCORE_URLS`

## 🌐 服务访问

启动成功后，可通过以下地址访问：

- **API服务**: http://服务器IP:3003
- **API文档**: http://服务器IP:3003/swagger
- **健康检查**: http://服务器IP:3003/api/RoomOccupancy/test

## 📋 核心功能模块

### 房间入住管理 (RoomOccupancy)
- 入住登记、退房管理
- 账单生成、支付处理
- 入住记录查询、统计

### 房间管理 (RoomManagement)
- 房间信息CRUD
- 房间状态管理
- 容量统计

### 设备管理 (DeviceManagement)
- 设备监控、故障检测
- 维护记录管理
- 状态轮询服务

### 健康监测 (HealthMonitoring)
- 生命体征数据采集
- 健康数据上报
- 历史记录查询

### 电子围栏 (ElectronicFence)
- GPS定位追踪
- 越界警报系统
- 活动轨迹记录

### IoT监控 (IoTMonitoring)
- 设备状态轮询
- 故障自动上报
- 状态同步服务

## 🔧 系统要求

### 服务器要求
- **操作系统**: Windows Server 2016+, Linux (Ubuntu 18.04+), macOS 10.15+
- **内存**: 最低 2GB，推荐 4GB+
- **存储**: 最低 1GB 可用空间
- **.NET运行时**: .NET 6.0 或更高版本

### 数据库要求
- **Oracle**: 11g 或更高版本
- **字符集**: AL32UTF8 (支持中文)
- **连接**: 确保网络连通性

## 🚨 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   # 检查端口占用
   netstat -ano | findstr :3003
   # 或修改启动脚本中的端口号
   ```

2. **数据库连接失败**
   - 检查连接字符串格式
   - 确认数据库服务状态
   - 验证用户权限

3. **权限不足 (Linux)**
   ```bash
   # 给予执行权限
   chmod +x scripts/start_server.sh
   ```

4. **.NET运行时未安装**
   - 下载地址: https://dotnet.microsoft.com/download
   - 安装 .NET 6.0 Runtime

### 日志查看

应用程序日志会显示在控制台中，包括：
- 数据库连接状态
- API请求日志
- 错误信息详情

## 📞 技术支持

如遇到部署问题，请检查：
1. 系统要求是否满足
2. 配置文件是否正确
3. 网络连接是否正常
4. 数据库权限是否充足

## 🔄 版本信息

### v2.0 版本特性
- ✅ 完整的房间入住管理功能
- ✅ 账单生成与支付系统
- ✅ 基于occupancy_id的防重复机制
- ✅ Oracle NULL值兼容性修复
- ✅ 完善的API文档和测试指南
- ✅ 后台设备监控服务
- ✅ 中文字符完全支持

### 账单生成逻辑
本版本账单生成逻辑已优化：
- 严格按照入住记录的occupancy_id生成账单
- 防止重复生成账单
- 支持同日入住退房（计算为1天）
- 自动跳过未退房记录

### 测试验证状态
- ✅ 所有12个房间入住管理API已通过测试
- ✅ 支付功能（全额支付、部分支付）正常
- ✅ 账单生成防重复机制正常
- ✅ Oracle数据库兼容性已验证

---

**版本**: v2.0  
**发布日期**: 2025-09-10  
**兼容性**: .NET 6.0+, Oracle 11g+  
**部署状态**: 生产就绪
